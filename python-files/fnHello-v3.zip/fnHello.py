import json

def handler(event, context):
    print("hello world from AWS CFN! This is the updated code!!!")

    return  "hello world from AWS CFN!"
