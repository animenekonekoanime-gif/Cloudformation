import json

def handler(event, context):
    print("hello world from AWS CFN!")

    return  "hello world from AWS CFN!"
